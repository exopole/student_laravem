@extends('layouts.master')

@section('content')

    <div class="container">
        @if(Session::has('message'))
            <p>{{ Session::get('message') }}</p>
        @endif
        {{-- une autre manière d'écrire l'action action="action('PostController@store')" --}}
        <form action="{{url('admin', ['post', $post->id,]) }}" method="POST" >
            {{ csrf_field() }}
            {{method_field('PUT')}}
             <div class="field">
                 <label for="title">Titre:</label>
                 <input type="text" name="title" value="{{$post->title}}">
                 @if($errors->has('title'))
					span {{$errors->first('title')}}
                 @endif
                 <label for="slug">Slug:</label>
                 <input type="text" name="slug" value="{{$post->slug}}">
                 @if($errors->has('slug'))
					span {{$errors->first('slug')}}
                 @endif

             </div>
            <div class="field">
                <label for="category_id">Catégorie</label>
                <select name="category_id" >

                    <option value="null">Non catégorisé</option>
                    @forelse($categories as $id=> $name)
                     	<option value="{{$id}}" {{check_select_edit($post->category_id, $id)}}>{{$name}}
                    	</option>

                    @empty
                        <p>No users</p>
                    @endforelse
                </select>
                 @if($errors->has('category_id'))
					span {{$errors->first('category_id')}}
                 @endif

            </div>
            <div class="field">
                <label for="category_id">Auteur</label>
                <select name="user_id" >
                    @forelse($users as $id=> $name)
                        <option value="{{$id}}" {{check_select_edit($post->user_id, $id)}}>{{$name}}</option>
                    @empty
                        <p>No users</p>
                    @endforelse
                </select>
            </div>
            <div class="field">
                <label for="status">Publié</label>
                <input type="radio" name="status" value="published" {{check_radio_edit($post->status, 'published')}}>
                <label for="status">dépublié</label>
                <input type="radio" name="status" value="unpublished" {{check_radio_edit($post->status, 'unpublished')}}>
                <label for="status">Brouillon</label>
                <input type="radio" name="status" value="draft" {{check_radio_edit($post->status, 'draft')}}>
                @if($errors->has('status'))
					span {{$errors->first('status')}}
                 @endif
            </div>
            <div class="field">
                <input type="date" name="published_at" value="{{$post->publish_at}}">
                @if($errors->has('date'))
					span {{$errors->first('date')}}
                 @endif
            </div>
            <div class="field">
                <label for="content">Contenu</label>
                <textarea name="content" id="" cols="30" rows="10">{{$post->content}} </textarea>
            </div>
            <input type="submit" class="submit">
        </form>
    </div>
@endsection

@section('sidebar')

@endsection