<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
</head>
<body>
	<header>
		<nav>
			<a href="{{url('category',1)}}">PHP</a>
			<a href="{{url('category',2)}}">MySQL</a>
		</nav>
	</header>

	<div>
		<div class="grid-2">
			<div class="content">
				@yield('content')
			</div>
			<div class="sidebar">
				@yield('sidebar')
				<nav>
					sidebar
				</nav>
			</div>
		</div>
	</div>
	<footer>
		

	</footer>
</body>
</html>