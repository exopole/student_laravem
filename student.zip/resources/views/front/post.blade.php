@extends('layouts.master')

@section('content')

<h1> Title : 

@if(!empty($post))

	{{$post['title']}} ; </h1>
	<img src="{{url('images', $post->thumbnail)}}">


@else
Unknow

@endif

@endsection

@section('sidebar')
Les mots clés :
<ul>
@forelse($post->tags as $tag)
	<li><a href="{{url('tag',$tag->id)}}" class="post_tag">{{$tag->name}}</a></li>
@empty
	<li>pas de mots clé</li>
@endforelse
</ul>

@endsection