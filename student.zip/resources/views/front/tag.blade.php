@extends('layouts.master')

@section('content')
Nom du tag => {{$tag->name}}
<br>

<ul>Article lié
@forelse($tag->posts as $post)
	<li><a href="{{url('article',$post->id)}}" class="post_tag">{{$post->title}}</a></li>
@empty
	<li>pas d'article lié</li>
@endforelse
</ul>

@endsection

@section('sidebar')

@endsection