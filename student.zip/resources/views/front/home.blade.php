@extends('layouts.master')

@section('content')


@if(!empty($posts))
<ul>
	@foreach($posts as $post)
		<li>
			<a href="{{url('article', [$post->id, $post->slug])}}">{{$post->title}}</a>
			@if(!empty($post->thumbnail))
				<p><img src="{{url('images', [$post->thumbnail])}}" alt=""></p>
			@endif
			<p>{{($post->category)? $post->category->title : 'non catégorisé'}}</p>
		</li>
	@endforeach
</ul>
@else
	<p>désolé aucun article</p>
@endif

@endsection

@section('sidebar')
@if(!empty($students))
<ul>
	@foreach($students as $student)
		<li>
			<a href="{{url('students', [$student->id])}}">{{$student->name}}</a>
		</li>
	@endforeach
</ul>
@else
	<p>désolé aucun Etudiant</p>
@endif

@endsection