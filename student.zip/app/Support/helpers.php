<?php

if (!function_exists('check_radio')){

	function check_radio($name, $value, $default = null){
		$old = old($name);

		if(!is_null($default) && empty($old)) return 'checked';

		if($old == $value) return 'checked';
	}
}

if (!function_exists('check_radio_edit')){

	function check_radio_edit($name, $value, $default = null){

		if(isset($name) && isset($name) && $name == $value) return 'checked';
	}
}




if (!function_exists('check_select')){

	function check_select($name, $value){
		if(old($name) == $value) return 'selected';
	}
}

if (!function_exists('check_select_edit')){

	function check_select_edit($id, $value){
		if(isset($id) && isset($value) && $id == $value) return 'selected';
	}
}

